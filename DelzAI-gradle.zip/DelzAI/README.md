# DelzAI ИИ 4.0 — Android-проект (Gradle)

WebView-обёртка над `app/src/main/assets/www/index.html`.

## Как собрать
1. Android Studio (Hedgehog или новее) → **Open** → выбрать папку проекта. Дождаться Gradle Sync (нужен интернет).
   Если студия ругается на отсутствие wrapper — в терминале проекта: `gradle wrapper --gradle-version 8.2`.
2. Тестовый APK: **Build → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`.
3. Для публикации: **Build → Generate Signed Bundle / APK**.

## Что внутри
- `MainActivity.java` — WebView по адресу `https://appassets.androidplatform.net` (безопасный контекст),
  выбор файлов (фото, видео, html, apk, zip, mp3 …), доступ к камере и микрофону, мост системной озвучки
  `AndroidTTS` (с тоном для мужского/женского голоса), сохранение «скачанных» blob-файлов в «Загрузки».
- minSdk 29 (Android 10+), targetSdk 34, пакет `com.delzai.app` (меняется в `app/build.gradle`).
- Чтобы обновить интерфейс, замените `app/src/main/assets/www/index.html`.
